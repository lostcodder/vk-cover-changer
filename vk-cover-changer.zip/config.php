<?php

$access_token = "---Access token---";
$group_id = "---Group id---";
$change_interval = 30;

$covers_dir = "cover";
$log_level = "verbose";